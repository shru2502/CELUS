--- Find the largest cake for the top 5 flavors.

--- Determine which flavors have the highest number of vegan cakes.

-- Identify the cake flavor of the first and last entries for each month.

--- Determine the month with the highest number of cakes and the one with the least.
